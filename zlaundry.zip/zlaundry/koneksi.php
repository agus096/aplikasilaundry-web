<?php
$servername = "localhost";
$database = "zlaundry";
$username = "root";
$password = "";
// Create connection
$kon = mysqli_connect($servername, $username, $password, $database);
?>