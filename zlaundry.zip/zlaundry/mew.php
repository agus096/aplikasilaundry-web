<?php

$id_inv = $_GET['id_inv'];

echo $id_inv;

?>