
<?php
   require 'base-url.php';
?>

<!-- Vendor js -->
<script src="<?= $base_url ?>assets/js/vendor.min.js"></script>
<!-- Parsley js-->
<script src="<?= $base_url ?>assets/libs/parsleyjs/parsley.min.js"></script>
<script src="<?= $base_url ?>assets/libs/selectize/js/standalone/selectize.min.js"></script>
<script src="<?= $base_url ?>assets/libs/multiselect/js/jquery.multi-select.js"></script>
<script src="<?= $base_url ?>assets/libs/devbridge-autocomplete/jquery.autocomplete.min.js"></script>
<script src="<?= $base_url ?>assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
<script src="<?= $base_url ?>assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>


<!-- datatables js -->
<script src="<?= $base_url ?>assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="<?= $base_url ?>assets/libs/datatables.net-select/js/dataTables.select.min.js"></script>
<script src="<?= $base_url ?>assets/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="<?= $base_url ?>assets/libs/pdfmake/build/vfs_fonts.js"></script>


<!-- App js-->
<script src="<?= $base_url ?>assets/js/app.min.js"></script>
<!-- flatpicker js-->
<script src="<?= $base_url ?>assets/libs/flatpickr/flatpickr.min.js"></script>
<!-- apexchart js-->
<script src="<?= $base_url ?>assets/libs/apexcharts/apexcharts.min.js"></script>
<!-- Clockpicker js-->
<script src="<?= $base_url ?>assets/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
<!--Datepicker js -->
<script src="<?= $base_url ?>assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<!--form picker Init js-->
<script src="<?= $base_url ?>assets/js/pages/form-pickers.init.js"></script>
<!-- Datatables init js -->
<script src="<?= $base_url ?>assets/js/pages/datatables.init.js"></script>
<!--Footable js -->
<script src="<?= $base_url ?>assets/libs/footable/footable.all.min.js"></script>
<!-- Footable Init js -->
<script src="<?= $base_url ?>assets/js/pages/foo-tables.init.js"></script>
<!-- select2 js-->
<script src="<?= $base_url ?>assets/libs/select2/js/select2.min.js"></script>
<!--sweet alert js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
<!--swithery js -->
<script src="<?= $base_url ?>assets/libs/mohithg-switchery/switchery.min.js"></script>
<!-- Tippy js-->
<script src="<?= $base_url ?>assets/libs/tippy.js/tippy.all.min.js"></script>
<!-- wizard js-->
<script src="<?= $base_url ?>assets/js/pages/form-wizard.init.js"></script>
<!--form acvanced Init js-->
<script src="<?= $base_url ?>assets/js/pages/form-advanced.init.js"></script>



<!-- jquery double membuat konflik karena itu dibuat $j -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- menampilkan nama berdasarkan no.WA -->
<script type="text/javascript">
        var $j = jQuery.noConflict();
        function isi_otomatis(){
        var whatsapp = $("#whatsapp").val();
        $j.ajax({
                url: 'tampilkan-nama.php',
                data:"whatsapp="+whatsapp ,
        }).success(function (data) {
                var json = data,
                obj = JSON.parse(json);
                $('#nama').val(obj.nama);
        });
        }
</script>



