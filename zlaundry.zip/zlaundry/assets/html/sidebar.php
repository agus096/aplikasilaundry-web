<!-- ========== Left Sidebar Start ========== -->
<div class="left-side-menu">
<div class="h-100" data-simplebar>

    <!--- Sidemenu -->
    <div id="sidebar-menu">

        <ul id="side-menu">

            <li>
                <a href="#Dashboards" data-bs-toggle="collapse">
                    <i class="fas fa-tachometer-alt"></i>
                    <span> Dashboards </span>
                </a>
                <div class="collapse" id="Dashboards">
                    <ul class="nav-second-level">
                        <li>
                            <a href="/zlaundry">Invoice</a>
                        </li>
                        <li>
                            <a href="pengeluaran">Pengeluaran</a>
                        </li>
                    </ul>
                </div>
            </li>


            <li>
                <a href="#Config" data-bs-toggle="collapse">
                    <i class="fas fa-cog"></i>
                    <span> Pengaturan </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="Config">
                    <ul class="nav-second-level">
                        <li>
                            <a href="config-umum">Umum</a>
                        </li>
                        <li>
                            <a href="config-service">Service</a>
                        </li>
                        <li>
                            <a href="config-customer">Customer</a>
                        </li>
                        <li>
                            <a href="kategori-pengeluaran">Kategori pengeluaran</a>
                        </li>
                        <li>
                            <a href="config-bca">BCA</a>
                        </li>
                    </ul>
                </div>
            </li>

            <li>
                <a href="#Laporan" data-bs-toggle="collapse">
                    <i class="fas fa-book"></i>
                    <span> Laporan </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="Laporan">
                    <ul class="nav-second-level">
                        <li>
                            <a href="list-notif-deadline">Notif deadline</a>
                        </li>
                        <li>
                            <a href="chart">Chart</a>
                        </li>
                    </ul>
                </div>
            </li>





        </ul>

    </div>
    <!-- End Sidebar -->
    <div class="clearfix"></div>
</div>
<!-- Sidebar -left -->
</div>