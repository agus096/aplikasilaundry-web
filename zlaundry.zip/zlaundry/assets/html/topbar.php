<?php
require 'query-config-umum.php';
?>

<!-- Topbar Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <ul class="list-unstyled topnav-menu float-end mb-0">
       
        <li class="dropdown d-none d-lg-inline-block">
            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" href="logout">
                <span style="margin-right:20px;"><?= $_SESSION['nama'] ?></span> 
            </a>
        </li>

        </ul>

        <!-- LOGO -->
        <div class="logo-box">
            <a href="/zlaundry" class="logo text-center">
                <span class="logo-sm text-white">
                    <img src="assets/images/washmachine.png" width="22">
                </span>
            
                <span class="logo-lg text-white <?= $d_font['val'] ?>" style="font-size:<?= $d_fontsize['val'] ?>px;">
                    <?= $d_merek['val'] ?>
                </span>
               
            </a>
        </div>

        <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
            <li>
                <button class="button-menu-mobile waves-effect waves-light">
                    <i class="mdi mdi-menu"></i>
                </button>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
</div>
<!-- end Topbar -->