<?php
//jika tidak ada sesion nama kembalikan ke hal.login
if (!isset($_SESSION['nama'])) {
  header("Location: login");
}
require 'base-url.php';
?>
<head>

        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?= $base_url ?>assets/images/favicon.ico">

         <!-- third party css -->
        <link href="<?= $base_url ?>assets/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= $base_url ?>assets/libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= $base_url ?>assets/libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= $base_url ?>assets/libs/datatables.net-select-bs5/css/select.bootstrap5.min.css" rel="stylesheet" type="text/css" />
        <!-- third party css end -->

        <link href="<?= $base_url ?>assets/libs/mohithg-switchery/switchery.min.css" rel="stylesheet" type="text/css" />

        <!--sweat alert-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" rel="stylesheet">

        <!-- Plugins css -->
        <link href="<?= $base_url ?>assets/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= $base_url ?>assets/libs/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
        <link href="<?= $base_url ?>assets/libs/selectize/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css" />

        <!-- Plugins css -->
        <link href="<?= $base_url ?>assets/libs/clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet" type="text/css" />
        
        <!--date picker-->
        <link href="<?= $base_url ?>assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />

        <!-- Bootstrap css -->
        <link href="<?= $base_url ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

        <!-- custom css-->
        <link href="<?= $base_url ?>assets/css/custom.css" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="<?= $base_url ?>assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style"/>

        <!-- icons fontawesome -->
		    <link href="<?= $base_url ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        
        <!-- icons materialdesign -->
        <!-- cari icon disini https://pictogrammers.github.io/@mdi/font/6.9.96/ -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/6.9.96/css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
        
        <!-- css footable -->
        <link href="https://cdn.jsdelivr.net/npm/footable@2.0.6/css/footable.core.min.css" rel="stylesheet" type="text/css" />
        
        <!-- Head js -->
        <script src="<?= $base_url ?>assets/js/head.js"></script>

        <!-- jquery -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js"></script>

        <!-- select2 css-->
        <link href="<?= $base_url ?>assets/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />

        <!-- ION Slider -->
        <link href="<?= $base_url ?>assets/libs/ion-rangeslider/css/ion.rangeSlider.min.css" rel="stylesheet" type="text/css"/>

    </head>