<!-- masih kosong karena masih di locahost  -->
<?php 
 $base_url = ' ';